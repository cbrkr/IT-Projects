/*
 * Created on: Sep 8, 2023
 *
 * ULID: <ejlope2>
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Random;
import java.util.Scanner;

/**
 * A password manager that asks for account and site information to output that
 * information with a generated password.
 *
 * @author Manny Lopez
 *
 */
public class PasswordVault
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner scnr = new Scanner(System.in);
		Random random = new Random();

		String webName;
		String userName;
		String userEmail;
		String userNote;

		System.out.println("Welcome to the Password Vault!");
		System.out.println("Let's create a new password entry.\n");
		System.out.print("Enter the website name: ");
		webName = scnr.nextLine();
		System.out.print("Enter the username: ");
		userName = scnr.nextLine();
		System.out.print("Enter the email: ");
		userEmail = scnr.nextLine();
		System.out.print("Add a note: ");
		userNote = scnr.nextLine();
		System.out.print("*****************\n" + "  Item Summary  \n" + "*****************\n");
		System.out.println("Website Name: " + webName);
		System.out.println("Website URL: " + "https://www." + webName.toLowerCase() + ".net");
		System.out.println("Email: " + userEmail);
		System.out.println("Username: " + userName);
		int pasInt1 = random.nextInt(1000 - 100 + 1) + 100;
		char pasChar1 = Character.toUpperCase((char) (random.nextInt(26) + 65));
		char pasChar2 = Character.toLowerCase((char) (random.nextInt(26) + 65));
		char pasChar3 = Character.toUpperCase((char) (random.nextInt(26) + 65));
		char pasChar4 = Character.toLowerCase((char) (random.nextInt(26) + 65));
		char pasChar5 = Character.toUpperCase((char) (random.nextInt(26) + 65));
		String pasChar0 = pasChar1 + "" + pasChar2 + "" + pasChar3 + "" + pasChar4 + "" + pasChar5;
		int pasInt2 = random.nextInt(100 - 10 + 1) + 10;
		String passWord = pasInt1 + "" + pasChar0 + "" + pasInt2;
		System.out.println("Password: " + passWord);
		System.out.println("Note: " + userNote);

	}

}
