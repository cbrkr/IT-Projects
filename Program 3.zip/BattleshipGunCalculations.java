/*
 * Created on: Oct 4, 2023
 *
 * ULID: <ejlope2>
 * Class: IT 168 
 */
package edu.ilstu;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * Determines what angle your naval gunship will need to be at to hit the enemy
 * ship at a certain distance.
 *
 * @author Manny Lopez
 *
 */
public class BattleshipGunCalculations
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner scnr = new Scanner(System.in);
		DecimalFormat meters = new DecimalFormat("#,##0.00#");

		final double GRAVITY = 9.8;

		int muzleA = 1;
		double muzzVel = 0.0;
		double enemyS = 0.0;
		double meterM = 0.0;
		double meterMax = 0.0;
		double meterMin = 0.0;
		String userQ;
		char userStop;
		char quitF = 'q';
		char quitFC = 'Q';
		boolean hitEnemy = false;

		System.out.print("Enter the muzzle velocity (between 500 and 1000): ");
		muzzVel = scnr.nextInt();

		while ((muzzVel < 500) || (muzzVel > 1000))
		{
			System.out.print("Muzzle velocity must be between 500 and 1000, try again: ");
			muzzVel = scnr.nextInt();
		}
		System.out.println("Naval Gunnery Helper!");

		do
		{
			System.out.print("\nPlease enter the distance (in meters) to the enemy ship:");
			enemyS = scnr.nextInt();

			while (!(hitEnemy == true) && muzleA <= 45)
			{
				meterM = ((Math.pow(muzzVel, 2) / GRAVITY) * (Math.sin(Math.toRadians(2 * muzleA))));

				meterMax = meterM + 100;
				meterMin = meterM - 100;

				if (enemyS <= meterMax && enemyS >= meterMin)
				{
					System.out.println("With the gun at angle " + muzleA + " the projectile will travel "
							+ meters.format(meterM) + " meters, and hit the enemy ship.");
					hitEnemy = true;
				} else
				{
					System.out.println("With the gun at angle " + muzleA + " the projectile will travel "
							+ meters.format(meterM) + " meters, so the enemy ship will not be hit.");
					muzleA += 5;
				}

				if (hitEnemy == true)
				{
					System.out.println("To hit the target the gun should be set at " + muzleA + " degrees.");
				} else
				{
					System.out.println("The enemy ship cannot be hit at this distance.");
				}

			}

			System.out.print("To quit, enter Q or q: ");
			userQ = scnr.next();

			userStop = userQ.charAt(0);

			muzleA = 1;
			hitEnemy = false;

		} while (!(userStop == quitF) && !(userStop == quitFC));

		System.out.println("Naval Gunnery Helper ended");
	}

}
