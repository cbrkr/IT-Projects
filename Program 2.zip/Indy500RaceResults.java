/*
 * Created on: Sep 14, 2023
 *
 * ULID: <ejlope2>
 * Class: IT 168 
 */
package edu.ilstu;

import java.text.NumberFormat;
import java.util.Random;
import java.util.Scanner;

/**
 * Calculates race results for the Indy 500 based on 3 racers that the user
 * inputs.
 *
 * @author Manny Lopez
 *
 */
public class Indy500RaceResults
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// Declaring imported utilities and formats:
		Scanner scnr = new Scanner(System.in);
		Random random = new Random();
		NumberFormat fmt = NumberFormat.getCurrencyInstance();

		// Print welcome statement:
		System.out.println("Welcome to the NASCAR Indy 500!\n");

		// Declaring constant variables:
		final double LAP_D = 2.5;
		final int BONUS_L = 200;
		final double EARN_L = 25.00;
		final double ENTRY_F = 150.00;
		final double BONUS_C = 18000.00;
		final double FORD_B = 3000.00;

		// Declaring local variables for first racer:
		String rfn1;
		String rln1;
		int laps1;
		String rvm1;
		int raceNum1 = random.nextInt(5000) + 1;
		double bonus1 = 0;

		// User inputs first racer:
		System.out.print("Please enter the racer’s first name: ");
		rfn1 = scnr.next();
		System.out.print("Please enter the racer’s last name: ");
		rln1 = scnr.next();
		String rtn1 = rfn1 + " " + rln1;
		System.out.print("Please enter the number of laps completed: ");
		laps1 = scnr.nextInt();
		System.out.print("Please enter the racer’s vehicle make: ");
		rvm1 = scnr.next();

		// If racer has a Ford and completed the race:
		if ((rvm1.equals("Ford")) && (laps1 >= BONUS_L))
			bonus1 += FORD_B;

		// If racer completed the race:
		if (laps1 >= BONUS_L)
			bonus1 += BONUS_C;

		// Calculating miles:
		double miles1 = laps1 * LAP_D;

		// Calculating base earnings:
		double earn1 = laps1 * EARN_L;

		// Multiply earnings depending on laps done:
		if ((laps1 >= 51) && (laps1 <= 100))
			earn1 *= 1.5;
		else if ((laps1 >= 101) && (laps1 <= 150))
			earn1 *= 1.75;
		else if ((laps1 >= 151) && (laps1 <= 200))
			earn1 *= 2.00;

		// Calculating net winnings:
		double netW1 = (earn1 + bonus1) - ENTRY_F;

		// Declaring local variables for second racer:
		String rfn2;
		String rln2;
		int laps2;
		String rvm2;
		int raceNum2 = random.nextInt(5000) + 1;
		double bonus2 = 0;

		// User inputs second racer:
		System.out.print("\nPlease enter the racer’s first name: ");
		rfn2 = scnr.next();
		System.out.print("Please enter the racer’s last name: ");
		rln2 = scnr.next();
		String rtn2 = rfn2 + " " + rln2;
		System.out.print("Please enter the number of laps completed: ");
		laps2 = scnr.nextInt();
		System.out.print("Please enter the racer’s vehicle make: ");
		rvm2 = scnr.next();

		// If racer has a Ford and completed the race:
		if ((rvm2.equals("Ford")) && (laps2 >= BONUS_L))
			bonus2 += FORD_B;

		// If racer completed the race:
		if (laps2 >= BONUS_L)
			bonus2 += BONUS_C;

		// Calculating miles:
		double miles2 = laps2 * LAP_D;

		// Calculating base earnings:
		double earn2 = laps2 * EARN_L;

		// Multiplying earnings depending on laps done:
		if ((laps2 >= 51) && (laps2 <= 100))
			earn2 *= 1.5;
		else if ((laps2 >= 101) && (laps2 <= 150))
			earn2 *= 1.75;
		else if ((laps2 >= 151) && (laps2 <= 200))
			earn2 *= 2.00;

		// Calculating net winnings:
		double netW2 = (earn2 + bonus2) - ENTRY_F;

		// Declaring local variables for third racer:
		String rfn3;
		String rln3;
		int laps3;
		String rvm3;
		int raceNum3 = random.nextInt(5000) + 1;
		double bonus3 = 0;

		// User inputs third racer:
		System.out.print("\nPlease enter the racer’s first name: ");
		rfn3 = scnr.next();
		System.out.print("Please enter the racer’s last name: ");
		rln3 = scnr.next();
		String rtn3 = rfn3 + " " + rln3;
		System.out.print("Please enter the number of laps completed: ");
		laps3 = scnr.nextInt();
		System.out.print("Please enter the racer’s vehicle make: ");
		rvm3 = scnr.next();

		// If racer has a Ford and completed the race:
		if ((rvm3.equals("Ford")) && (laps3 >= BONUS_L))
			bonus3 += FORD_B;

		// If racer completed the race:
		if (laps3 >= BONUS_L)
			bonus3 += BONUS_C;

		// Calculating miles:
		double miles3 = laps3 * LAP_D;

		// Calculating base earnings:
		double earn3 = laps3 * EARN_L;

		// Multiplying earnings depending on laps done:
		if ((laps3 >= 51) && (laps3 <= 100))
			earn3 *= 1.5;
		else if ((laps3 >= 101) && (laps3 <= 150))
			earn3 *= 1.75;
		else if ((laps3 >= 151) && (laps3 <= 200))
			earn3 *= 2.00;

		// Calculating net winnings:
		double netW3 = (earn3 + bonus3) - ENTRY_F;

		// Print Indy500 race result for top 3 racers:
		System.out.print("\nNASCAR Indy 500 Race Results\n");
		System.out.printf("%-8s%-14s%-10s%-10s%-10s%-18s%-10s%14s%n", "Bib#", "Name", "Make", "Laps", "Miles",
				"Base Winnings", "Bonus", "Net Winnings");
		System.out.print(
				"----------------------------------------------------------------------------------------------");
		System.out.printf("\n%-8s%-14s%-10s%-10s%-10s%-18s%-10s%14s%n", raceNum1, rtn1.toLowerCase(), rvm1, laps1,
				miles1, fmt.format(earn1), fmt.format(bonus1), fmt.format(netW1));
		System.out.printf("\n%-8s%-14s%-10s%-10s%-10s%-18s%-10s%14s%n", raceNum2, rtn2.toLowerCase(), rvm2, laps2,
				miles2, fmt.format(earn2), fmt.format(bonus2), fmt.format(netW2));
		System.out.printf("\n%-8s%-14s%-10s%-10s%-10s%-18s%-10s%14s%n", raceNum3, rtn3.toLowerCase(), rvm3, laps3,
				miles3, fmt.format(earn3), fmt.format(bonus3), fmt.format(netW3));

		// Print totals:
		System.out.println("\nTotal Miles Covered: " + (miles1 + miles2 + miles3));
		System.out.println("Total Base Winnings: " + fmt.format(earn1 + earn2 + earn3));
		System.out.println("Total Bonus Winnings: " + fmt.format(bonus1 + bonus2 + bonus3));
		System.out.println("Total Net Winnings: " + fmt.format(netW1 + netW2 + netW3));
	}

}
